# Stan projektu — backend v0.7

- Backend Node.js: przygotowany lokalnie; przed wdrożeniem wymaga publikacji plików w repozytorium.
- API: `/health`, `/api/markets`; publiczny Binance Spot REST; bez handlu.
- Testy: `node --test` / `npm test`.
- Wdrożenie: konfiguracja Render Blueprint w `render.yaml`; nie oznacza to, że usługa została utworzona lub uruchomiona.
- Ograniczenia: publiczne API, limity giełdy i darmowego hostingu; brak gwarancji pracy 24/7.
