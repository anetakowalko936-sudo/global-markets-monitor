# Global Markets Monitor — wersja 0.5 (katalog źródeł i pokrycia)

## Co działa
- Responsywny pulpit na telefon i komputer.
- Publiczne notowania wybranych par krypto przez Binance market-data API.
- Katalog 28 głównych giełd/parkietów z wielu regionów (katalog nie oznacza osobnego podłączenia każdej giełdy).
- Zakładka „Źródła API” z konektorem Quova dla przykładowych instrumentów globalnych (akcje, ETF, indeksy, FX, krypto, futures — dostępność zależy od planu i identyfikatora).
- Klucz Quova trzymany wyłącznie w pamięci aktualnie otwartej strony; nie jest zapisywany do localStorage.
- Jawne wyświetlanie braku danych zamiast wymyślania ceny.

## Podłączenie źródła Quova
1. Otwórz stronę przez HTTPS lub lokalny serwer. Niektóre przeglądarki mogą blokować żądania API z pliku `file://`.
2. Utwórz klucz w panelu dostawcy i wklej go w zakładce „Źródła API”. Dokumentacja: https://quova.io/docs/.
3. Kliknij „Połącz / sprawdź”, a następnie „Pobierz notowania przykładowe”.
4. Konektor próbuje pobrać kwotowania z endpointu `/v1/quotes`. Jeśli dostawca, plan, przeglądarka/CORS lub symbol nie pozwoli na odpowiedź, aplikacja pokaże błąd, a nie fikcyjną cenę.

## Ważne ograniczenia
- To nie jest podłączenie dosłownie wszystkich giełd świata. Żaden pojedynczy klucz/API nie powinien być traktowany jako gwarancja kompletnego pokrycia wszystkich instrumentów i wszystkich lokalnych parkietów.
- Dostępność danych, opóźnienie, zakres instrumentów, limity i opłaty zależą od planu dostawcy oraz licencji giełdowych.
- Klucz w aplikacji statycznej nie jest bezpieczny dla wdrożenia publicznego: nie używaj kluczy z uprawnieniami transakcyjnymi. W wersji produkcyjnej klucz powinien być przechowywany po stronie backendu.
- Automatyczne odświeżanie Binance działa wyłącznie, gdy strona jest otwarta. Brak monitoringu 24/7, powiadomień e-mail i backendu.
- Dane służą do obserwacji i edukacji, nie stanowią porady inwestycyjnej.


## Metadane wiarygodności notowań (v0.3)
- Tabele pokazują dostawcę danych, czas notowania zwrócony przez źródło oraz szacowane opóźnienie względem zegara urządzenia.
- Jeśli źródło nie zwraca znacznika czasu, aplikacja wyświetla „Brak znacznika czasu źródłowego” i „Nieznane”, zamiast zgadywać.
- W kryptowalutach używany jest publiczny endpoint Binance 24h ticker; znacznik `closeTime` jest używany jako czas ostatniej transakcji zgłoszony przez API. Opóźnienie to szacunek i zależy m.in. od synchronizacji zegara urządzenia.
- Dla innych rynków ta informacja pojawi się tylko wtedy, gdy skonfigurowany dostawca faktycznie zwraca znacznik czasu. To nadal nie oznacza, że wszystkie światowe giełdy są podłączone.


## Wersja 0.4 — sygnały publiczne i dark web

Dodano sekcję „Sygnały i dark web” z zakresem monitoringu makroekonomii, geopolityki, przepływów/pozycjonowania i cyberzagrożeń oraz przyciskiem pobrania publicznych metadanych o najnowszych ujawnieniach ransomware z CTI.FYI (`/api/v1/posts/recent?limit=20`). Dane są oznaczane jako niezweryfikowane sygnały. Aplikacja nie otwiera adresów .onion ani nie pobiera skradzionych plików, haseł lub danych osobowych.

Publiczne API może być niedostępne z poziomu statycznej strony z powodu CORS, limitów lub zmian API. W takim przypadku wymagany jest backend proxy. Pozostałe moduły rynkowe opisują zakres docelowy; nie oznaczają automatycznie podłączenia wszystkich giełd ani wszystkich klas aktywów.


## Wersja 0.5 — katalog źródeł i ograniczenia integracji

Nowa zakładka „Katalog źródeł” zawiera odnośniki do dokumentacji dostawców i jawny status integracji:
- Binance — podłączone dla wybranych par krypto przez publiczne REST API.
- CTI.FYI — pobieranie publicznych metadanych ransomware na żądanie; możliwe ograniczenia CORS/limity.
- New York Fed — oficjalne dane rynku pieniężnego; w katalogu, nie podłączone do tabel notowań.
- IMF — makroekonomia przez SDMX; w katalogu, nie podłączone.
- Trading Economics — wskaźniki, FX, indeksy i rentowności; wymaga klucza/planu, nie podłączone.
- CME Group — wybrane instrumenty pochodne i dane rynkowe; wymaga konfiguracji/licencji, nie podłączone.
- Quova — istnieje konektor próbny w ustawieniach, ale połączenie należy traktować jako niepotwierdzone do czasu udanej odpowiedzi dla konkretnego symbolu.
- STIX/TAXII — standard i źródła cyber threat intelligence; w katalogu, nie podłączone.

Ta wersja nie oznacza, że wszystkie te API są już pobierane. Rzetelne pokrycie wymaga testu endpointów, kluczy tam gdzie są wymagane, weryfikacji timestampów, limitów oraz licencji redystrybucyjnych. Dla produkcji potrzebny jest backend, aby nie ujawniać kluczy API w przeglądarce.


## v0.6 — kalkulator symulacji inwestycji

Dodano zakładkę „Symulator inwestycji” z parametrami: kapitał początkowy, miesięczne wpłaty, okres, roczna stopa zwrotu, opłaty, inflacja i opcjonalny podatek od zysku. Kalkulator wylicza wartość końcową po opłatach i uproszczonym podatku, sumę wpłat, zysk/stratę nominalną oraz szacunkową wartość realną w dzisiejszych PLN.

Ważne ograniczenia: to scenariusz matematyczny, a nie prognoza. Nie modeluje zmienności ani kolejności stóp zwrotu, spreadów, prowizji transakcyjnych, kursów walut ani szczegółowych zasad podatkowych. Domyślny podatek wynosi 0% i użytkownik może go zmienić. Wynik nie stanowi porady inwestycyjnej ani podatkowej.
