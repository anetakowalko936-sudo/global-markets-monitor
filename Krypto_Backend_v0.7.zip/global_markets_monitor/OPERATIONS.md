# Uruchamianie backendu Krypto

Wymagania: Node.js 20+ (zalecane 22). Backend pobiera wyłącznie publiczne dane spot Binance i nie składa zleceń.

## Lokalnie
1. W katalogu z `package.json` uruchom `npm test`.
2. Uruchom `npm start`.
3. Sprawdź `http://localhost:3000/health` oraz `http://localhost:3000/api/markets`.

## Wdrożenie Render (bezpłatny plan, dostępność i limity zależą od dostawcy)
1. Wypchnij pliki repozytorium do GitHuba.
2. W Render wybierz New → Blueprint i wskaż repozytorium z plikiem `render.yaml`.
3. Sprawdź konfigurację, wybierz bezpłatny plan i zatwierdź wdrożenie.
4. Po wdrożeniu sprawdź `/health` i `/api/markets`. Usługi bezpłatne mogą usypiać się przy braku ruchu; to nie gwarantuje monitoringu 24/7.

## Endpointy
- `GET /health` — stan procesu.
- `GET /api/markets` — przykładowe pary BTCUSDT, ETHUSDT, BNBUSDT, SOLUSDT, XRPUSDT.
- `GET /api/markets?symbols=BTCUSDT,ETHUSDT` — wybrane symbole (1–20).

Każdy rekord zawiera źródło, symbol, status, `observedAt` i `retrievedAt`; niedostępne dane są jawnie oznaczone. Status `stale` oznacza znacznik czasu starszy niż 30 sekund lub z przyszłości. Dane 24h Binance nie są pełnym strumieniem transakcji. Endpoint pobiera dane na żądanie, nie działa jako ciągły proces subskrybujący giełdę.
