import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const MAX_AGE_MS = 30_000;
const DEFAULT_SYMBOLS = ['BTCUSDT', 'ETHUSDT', 'BNBUSDT', 'SOLUSDT', 'XRPUSDT'];

function json(res, status, body) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(JSON.stringify(body));
}

function validTicker(t) {
  if (!t || typeof t !== 'object') return false;
  const price = Number(t.lastPrice);
  const closeTime = Number(t.closeTime);
  return typeof t.symbol === 'string' && /^[A-Z0-9]{5,20}$/.test(t.symbol) && Number.isFinite(price) && price > 0 && Number.isFinite(closeTime) && closeTime > 0;
}

export function createServer({ fetchImpl = globalThis.fetch, now = () => Date.now(), frontendPath = path.join(ROOT, 'index.html') } = {}) {
  return http.createServer(async (req, res) => {
    const url = new URL(req.url || '/', 'http://localhost');
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.setHeader('allow', 'GET, HEAD');
      return json(res, 405, { error: 'Method not allowed' });
    }
    if (url.pathname === '/health') {
      return json(res, 200, { status: 'ok', service: 'global-markets-monitor', timestamp: new Date(now()).toISOString(), trading: 'disabled' });
    }
    if (url.pathname === '/api/markets') {
      const symbols = (url.searchParams.get('symbols') || DEFAULT_SYMBOLS.join(','))
        .split(',').map(s => s.trim().toUpperCase()).filter(Boolean);
      if (!symbols.length || symbols.length > 20 || symbols.some(s => !/^[A-Z0-9]{5,20}$/.test(s))) {
        return json(res, 400, { error: 'Podaj od 1 do 20 poprawnych symboli, np. BTCUSDT,ETHUSDT.' });
      }
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      try {
        const response = await fetchImpl('https://api.binance.com/api/v3/ticker/24hr', { signal: controller.signal, headers: { accept: 'application/json' } });
        if (!response.ok) return json(res, 502, { error: 'Źródło Binance zwróciło błąd.', sourceStatus: response.status });
        const payload = await response.json();
        if (!Array.isArray(payload)) return json(res, 502, { error: 'Nieprawidłowy format danych źródłowych.' });
        const bySymbol = new Map(payload.filter(validTicker).map(t => [t.symbol, t]));
        const retrievedAt = new Date(now()).toISOString();
        const markets = symbols.map(symbol => {
          const t = bySymbol.get(symbol);
          if (!t) return { source: 'Binance Spot REST', symbol, status: 'unavailable', observedAt: null, retrievedAt, price: null };
          const closeTime = Number(t.closeTime);
          const ageMs = now() - closeTime;
          return {
            source: 'Binance Spot REST', symbol, status: ageMs >= 0 && ageMs <= MAX_AGE_MS ? 'ok' : 'stale',
            currency: symbol.endsWith('USDT') ? 'USDT' : null,
            price: Number(t.lastPrice), changePercent24h: Number.isFinite(Number(t.priceChangePercent)) ? Number(t.priceChangePercent) : null,
            volume24h: Number.isFinite(Number(t.volume)) ? Number(t.volume) : null,
            observedAt: new Date(closeTime).toISOString(), retrievedAt,
            ageMs: Math.max(0, ageMs)
          };
        });
        return json(res, 200, { source: 'Binance Spot REST', retrievedAt, markets, tradingEnabled: false });
      } catch (error) {
        const timedOut = error?.name === 'AbortError';
        return json(res, 502, { error: timedOut ? 'Przekroczono czas oczekiwania na Binance.' : 'Nie udało się pobrać danych z Binance.', retryable: true });
      } finally { clearTimeout(timeout); }
    }
    if (url.pathname === '/' || url.pathname === '/index.html') {
      try {
        const html = fs.readFileSync(frontendPath);
        res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'x-content-type-options': 'nosniff', 'cache-control': 'no-cache' });
        return res.end(req.method === 'HEAD' ? undefined : html);
      } catch { return json(res, 404, { error: 'Nie znaleziono pliku interfejsu index.html.' }); }
    }
    return json(res, 404, { error: 'Not found' });
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const server = createServer();
  server.listen(PORT, HOST, () => console.log(`Global Markets Monitor listening on ${HOST}:${PORT}`));
  const shutdown = () => server.close(() => process.exit(0));
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}
