import test from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from '../server.js';

async function withServer(options, fn) {
  const server = createServer(options);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const { port } = server.address();
  try { await fn(`http://127.0.0.1:${port}`); }
  finally { await new Promise((resolve, reject) => server.close(err => err ? reject(err) : resolve())); }
}

test('GET /health reports healthy and trading disabled', async () => {
  await withServer({ now: () => 1_800_000_000_000 }, async base => {
    const r = await fetch(`${base}/health`); const data = await r.json();
    assert.equal(r.status, 200); assert.equal(data.status, 'ok'); assert.equal(data.trading, 'disabled');
  });
});

test('markets returns validated timestamped ticker records', async () => {
  const now = 1_800_000_000_000;
  await withServer({ now: () => now, fetchImpl: async () => ({ ok: true, json: async () => [{ symbol: 'BTCUSDT', lastPrice: '65000', closeTime: now - 1000, priceChangePercent: '1.2', volume: '10' }] }) }, async base => {
    const r = await fetch(`${base}/api/markets?symbols=BTCUSDT,ETHUSDT`); const data = await r.json();
    assert.equal(r.status, 200); assert.equal(data.markets[0].status, 'ok'); assert.equal(data.markets[0].price, 65000);
    assert.ok(data.markets[0].observedAt); assert.ok(data.markets[0].retrievedAt);
    assert.equal(data.markets[1].status, 'unavailable'); assert.equal(data.tradingEnabled, false);
  });
});

test('markets rejects invalid symbols', async () => {
  await withServer({}, async base => { const r = await fetch(`${base}/api/markets?symbols=BTCUSDT,%3Cbad%3E`); assert.equal(r.status, 400); });
});

test('upstream HTTP failure becomes 502, not fabricated market data', async () => {
  await withServer({ fetchImpl: async () => ({ ok: false, status: 429 }) }, async base => {
    const r = await fetch(`${base}/api/markets?symbols=BTCUSDT`); const data = await r.json();
    assert.equal(r.status, 502); assert.match(data.error, /Binance/);
  });
});

test('unsupported route returns 404', async () => {
  await withServer({}, async base => { const r = await fetch(`${base}/missing`); assert.equal(r.status, 404); });
});
